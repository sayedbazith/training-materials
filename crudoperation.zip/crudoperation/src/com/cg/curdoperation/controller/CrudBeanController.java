package com.cg.curdoperation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.curdoperation.dto.CrudBean;
import com.cg.curdoperation.service.ICrudBeanService;
@Controller
public class CrudBeanController {

	@Autowired
	ICrudBeanService service;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String home() 
	{
		return "home";
	}
	
	@RequestMapping(value="add", method=RequestMethod.GET)
	public String add() 
	{
		return "add";
	}
	
	@RequestMapping(value="addDetails",method=RequestMethod.POST)
	public String addDetails(@RequestParam("name") String name,@RequestParam("number") long phoneNumber/*,@RequestParam("id") int id*/) 
	{
		CrudBean bean=new CrudBean();
		//bean.setId(id);
		bean.setName(name);
		bean.setPhoneNumber(phoneNumber);
		boolean result=service.add(bean);
		if(result)
			return "success";
		else
			return "add";
	}
	
	@RequestMapping(value="delete")
	public String delete() 
	{
		return "delete";
	}
	
	@RequestMapping(value="deleteDetails")
	public String deleteDetails(@RequestParam("id") int id) 
	{
		boolean result=service.delete(id);
		if(result)
			return "success";
		else
			return "delete";
	}
}