package com.cg.curdoperation.service;

import com.cg.curdoperation.dto.CrudBean;

public interface ICrudBeanService {
	boolean add(CrudBean bean);

	boolean delete(int id);
}
