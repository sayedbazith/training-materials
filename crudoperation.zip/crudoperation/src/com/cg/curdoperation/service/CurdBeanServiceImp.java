package com.cg.curdoperation.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.curdoperation.dao.ICrudBeanDAO;
import com.cg.curdoperation.dto.CrudBean;
@Service
@Transactional
public class CurdBeanServiceImp implements ICrudBeanService {
	
	@Autowired
	ICrudBeanDAO dao;
	@Override
	public boolean add(CrudBean bean) {
		// TODO Auto-generated method stub
		return dao.add(bean);
	}
	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return dao.delete(id);
	}

}
