package com.cg.curdoperation.dao;

import com.cg.curdoperation.dto.CrudBean;

public interface ICrudBeanDAO {
	boolean add(CrudBean bean);

	boolean delete(int id);
}
