package com.cg.curdoperation.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.curdoperation.dto.CrudBean;
@Repository
public class CrudBeanDAOImp implements ICrudBeanDAO {
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public boolean add(CrudBean bean) {
		// TODO Auto-generated method stub
		em.persist(bean);
		em.flush();
		return true;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		boolean isValid=false;
		CrudBean bean=null;
		Query query=em.createQuery("from CrudBean");
		List<CrudBean> list=query.getResultList();
		for (CrudBean crudBean : list) {
			if(crudBean.getId()==id)
				bean=crudBean;
		}
		if(bean!=null) 
		{
			em.remove(bean);
			em.flush();
			isValid=true;
		}
		return isValid;
	}
}
